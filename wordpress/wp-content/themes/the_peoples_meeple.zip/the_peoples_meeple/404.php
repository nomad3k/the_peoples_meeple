<?php
  wp_title('Not Found');
  get_header();
?>
<div style="text-align: center">
  <p>Guess you rolled a 1 on Spot Hidden!</p>
</div>
<?php get_footer(); ?>
