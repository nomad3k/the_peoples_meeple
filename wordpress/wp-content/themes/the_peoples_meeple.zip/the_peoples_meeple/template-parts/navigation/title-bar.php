<div class="tpm-title-bar">
  <div class="tpm-title-bar__container">
    <div class="tpm-title-bar__lhs">
      <a href="/">
        <img src="/wp-content/themes/the_peoples_meeple/assets/images/logo_96.png" alt="Logo" />
      </a>
    </div>
    <div class="tpm-title-bar__centre">
      <h1 class="tpm-title-bar__centre-header">
        <a href="/">
          <span>thepeoplesmeeple</span><span class="not-mobile">.com</span>
        </a>
      </h1>
      <div class="tpm-title-bar__centre-sub-header">
        <a href="/eat/">Eat</a>
        <span> - </span>
        <a href="/drink/">Drink</a>
        <span> - </span>
        <a href="/play/">Play</a>
      </div>
    </div>
    <div class="tpm-title-bar__rhs">

    </div>
  </div>
</div>
