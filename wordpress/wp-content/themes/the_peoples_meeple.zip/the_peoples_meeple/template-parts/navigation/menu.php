<div class="tpm-menu">
  <div class="tpm-menu__fill"></div>
  <div class="tpm-menu__container">
    <div class="tpm-menu__lhs">
      <a href="/book-a-table">&larr; Book a Table</a>
    </div>
    <div class="tpm-menu__lhs-separator"></div>
    <div class="tpm-menu__centre">
      <h1><?php the_title() ?></h1>
    </div>
    <div class="tpm-menu__rhs-separator"></div>
    <div class="tpm-menu__rhs">
      <a href="/blog">Read the Blog &rarr;</a>
    </div>
  </div>
  <div class="tpm-menu__fill"></div>
</div>
