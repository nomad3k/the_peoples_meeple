<?php ?>
		</div>
	</div>

	<footer class="tpm-template__footer">
		<div class="tpm-container">
			&copy; 2019
		</div>
	</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>
